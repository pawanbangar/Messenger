package com.chatapp.themessengerapp.Notification;

public class Success {
    private String success;
}
