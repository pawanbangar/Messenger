package com.chatapp.themessengerapp.Activity;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.chatapp.themessengerapp.R;

public class ChatActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);



        }


}
