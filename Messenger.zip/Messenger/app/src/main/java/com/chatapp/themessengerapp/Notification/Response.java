package com.chatapp.themessengerapp.Notification;

public class Response {
    private int success;
}
