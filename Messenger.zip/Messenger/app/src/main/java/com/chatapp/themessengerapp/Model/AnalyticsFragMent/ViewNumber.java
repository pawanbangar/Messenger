package com.chatapp.themessengerapp.Model.AnalyticsFragMent;

public class ViewNumber {
    private int position;

    public ViewNumber(int position) {
        this.position = position;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }
}
